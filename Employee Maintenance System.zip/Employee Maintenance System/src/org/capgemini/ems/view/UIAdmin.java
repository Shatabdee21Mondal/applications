package org.capgemini.ems.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.capgemini.ems.bean.DepartmentBean;
import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.dao.AdminDAOImpl;
import org.capgemini.ems.dao.EmployeeDAOImpl;
import org.capgemini.ems.dao.IAdminDAO;
import org.capgemini.ems.dao.IEmployeeDAO;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;
import org.capgemini.ems.service.AdminServiceImpl;
import org.capgemini.ems.service.EmployeeServiceImpl;
import org.capgemini.ems.service.IAdminService;
import org.capgemini.ems.service.IEmployeeService;
import org.capgemini.ems.service.Validation;


public class UIAdmin {
	private static Scanner scanner = new Scanner(System.in);
	static EmployeeBean employeeBean=new EmployeeBean();
	static IAdminService adminService =new AdminServiceImpl();
	static IEmployeeService employeeService=new EmployeeServiceImpl();
	static IAdminDAO adminDAO=new AdminDAOImpl();
	static IEmployeeDAO employeeDAO=new EmployeeDAOImpl();
	public void adminModule(int option1) throws EmployeeMaintenanceSystemException {

		switch (option1) {


		case 1: System.out.println("Enter EmpId: ");

		String empId=scanner.nextLine();
		Validation validation=new Validation();

		if(validation.isValidEmpId(empId)){

			System.out.println("Enter empFirstName: ");
			String empFirstName=scanner.nextLine();

			if(validation.isValidFirstName(empFirstName)){

				System.out.println("Enter empLastName: ");
				String empLastName=scanner.nextLine();

				if(validation.isValidLastName(empLastName)){

					System.out.println("Enter empDateOfBirth: ");
					String empDateOfBirth=scanner.nextLine();
					DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
					LocalDate DOB=LocalDate.parse(empDateOfBirth,formatter);


					if(validation.isValidDOB(empDateOfBirth)){

						System.out.println("Enter empDateOfJoining");
						String empDateOfJoining=scanner.nextLine();
						DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
						LocalDate DOJ=LocalDate.parse(empDateOfJoining,formatter1);


						if(validation.isValidDOJ(empDateOfJoining)){
							System.out.println("Department Details:");
							List<DepartmentBean> bean1=adminService.displayDepartmentDetails();
							System.out.println(bean1); 
							System.out.println("Enter empDeptId: ");
							Integer empDeptId=scanner.nextInt();
							scanner.nextLine();

							System.out.println("Enter empGrade: ");
							String empGrade=scanner.nextLine();


							if(validation.isValidGrade(empGrade)){

								System.out.println("Enter empDesignation: ");
								String empDesignation=scanner.nextLine();




								System.out.println("Enter empBasic: ");
								Integer empBasic=scanner.nextInt();



								System.out.println("Enter empGender: ");
								String empGender=scanner.next();
								scanner.nextLine();

								if(validation.isValidGender(empGender)){

									System.out.println("Enter empMaritalStatus: ");
									String empMaritalStatus=scanner.next();
									scanner.nextLine();

									if(validation.isValidMartialStatus(empMaritalStatus)){

										System.out.println("Enter empHomeAddress: ");
										String empHomeAddress=scanner.nextLine();										

										if(validation.isValidHomeAddress(empHomeAddress)){

											System.out.println("Enter empContactNum: ");
											String empContactNum=scanner.nextLine();											

											if(validation.isValidContactNumber(empContactNum)){

												employeeBean.setEmpId(empId);
												employeeBean.setEmpFirstName(empFirstName);
												employeeBean.setEmpLastName(empLastName);						
												employeeBean.setEmpDateOfBirth(DOB);
												Long sh=ChronoUnit.YEARS.between(DOB, DOJ);
												if(sh>=18&&sh<=58){
													employeeBean.setEmpDateOfJoining(DOJ);
													employeeBean.setEmpDeptId(empDeptId);
													employeeBean.setEmpGrade(empGrade);
													employeeBean.setEmpDesignation(empDesignation);
													employeeBean.setEmpBasic(empBasic);
													employeeBean.setEmpGender(empGender);
													employeeBean.setEmpMaritalStatus(empMaritalStatus);
													employeeBean.setEmpHomeAddress(empHomeAddress);
													employeeBean.setEmpContactNum(empContactNum);
													int n=adminService.addEmployeeDetails(employeeBean);
													if(n!=0) {
														System.out.println("Succesfully inserted");
													}


												}else{
													System.out.println("Age must be greter than 18");
												}

											}else{
												System.out.println("Please Enter valid Contact number !!!");
											}

										}else{
											System.out.println("Please Enter valid Home address !!!");
										}

									}else{
										System.out.println("Please Enter valid Martial status !!!");
									}


								}else{
									System.out.println("Please Enter valid Gender !!!");
								}

							}else{
								System.out.println("Please Enter valid Grade !!!");
							}
						}else{
							System.out.println("Enter valid Date of Joining Format !!!");
						}
					}else{
						System.out.println("Enter valid Date of Birth Format !!!");
					}

				}else{
					System.out.println("Please Enter valid Last Name !!!");
				}
			}else{
				System.out.println("Please Enter valid first Name !!!");
			}
		}else{
			System.out.println("Please Enter valid empID !!!");
		}


		break;  
		case 2:Validation validation1=new Validation();
		System.out.println("Enter your employee Id: ");
		String empid=scanner.nextLine();
		if(adminService.isValidEmpId(empid)){
			List<EmployeeBean> empBean2;
			empBean2=adminService.getAllEmployeeDetails(empid);
			Iterator<EmployeeBean> iterator1=empBean2.iterator();
			while(iterator1.hasNext()){
				System.out.println(iterator1.next());
			}
			System.out.println("\n");
			System.out.println("Modify your Details here...");
			System.out.println("\n");
			System.out.println("Employee id: "+empid);

			System.out.println("Enter new First Name: ");
			String fname=scanner.nextLine();

			if(validation1.isValidFirstName(fname)){
				System.out.println("New First Name:"+fname);

				System.out.println("Enter New Last Name:");
				String lname=scanner.nextLine();

				if(validation1.isValidLastName(lname)){
					System.out.println("New Last Name:"+lname);

					System.out.println("Enter New Dept Id: ");
					Integer deptId=scanner.nextInt();
					System.out.println("New Dept Id: "+deptId);
					System.out.println("Enter new Grade:");
					scanner.nextLine();
					String grade=scanner.nextLine();
					
					if(validation1.isValidGrade(grade)){
						
						System.out.println("New grade:"+grade);
						System.out.println("Enter new Designation: ");
						String designation=scanner.nextLine();
						System.out.println("New Designation: "+designation);
						System.out.println("Enter New Basic: ");
						Integer basic=scanner.nextInt();
						System.out.println("New Basic: "+basic);
						System.out.println("Enter updated Marital status: ");
						scanner.nextLine();
						String maritalStatus=scanner.nextLine();

						if(validation1.isValidMartialStatus(maritalStatus)){

							System.out.println("Updated Marital status: "+maritalStatus);
							System.out.println("Enter Updated Home address: ");
							String hAddress=scanner.nextLine();

							if(validation1.isValidHomeAddress(hAddress)){

								System.out.println("Updated Home address: "+hAddress);
								System.out.println("Enter Updated contact no: ");
								String contact=scanner.nextLine();

								if(validation1.isValidContactNumber(contact)){

									System.out.println("Updated Contact: "+contact);

									Integer Update=adminService.UpdateDetails(empid,fname,lname,deptId,grade,designation,basic,maritalStatus,hAddress,contact);

									if(Update>0){
										System.out.println("Updated Successfully...");
									}
									else{
										System.out.println("Failed to Update...");
									}
								}else{
									System.out.println("Please Enter valid Contact number !!!");
								}

							}else{
								System.out.println("Please Enter valid Home address !!!");
							}

						}else{
							System.out.println("Please Enter valid Martial status !!!");
						}
					}else{
						System.out.println("Please Enter valid Grade !!!");
					}
				}else{
					System.out.println("Please Enter valid Last Name !!!");
				}
			}else{
				System.out.println("Please Enter valid first Name !!!");
			}
		}else{
			System.out.println("Employee ID does not exist. So, please enter valid Employee Id !! ");
		}
		break; 





		case 3:
			List<EmployeeBean> employeeList=getAllEmployeeDetails();
			showEmployee(employeeList);


			break;
		case 4:
			System.out.print("Admin Exited from Employee Maintenance System");
			System.exit(0);
			break;
		default:
			System.out.println("Enter a valid option[1-4]");
		}


	}
	private static void showEmployee(List<EmployeeBean> employeeList) {
		if(employeeList!=null){
			Iterator<EmployeeBean> iterator=employeeList.iterator();
			while(iterator.hasNext()){
				System.out.println(iterator.next());
			}
		}else{
			System.out.println("No data found");
		}


	}
	private static List<EmployeeBean> getAllEmployeeDetails() throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeList=adminDAO.getAllEmployeeDetails();
		return employeeList;


	}

}
