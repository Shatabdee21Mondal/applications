package org.capgemini.ems.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.dao.EMSDAOImpl;
import org.capgemini.ems.dao.IEMSDAO;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;
import org.capgemini.ems.service.EMSServiceImpl;
import org.capgemini.ems.service.IEMSService;





public class Presentation {

	private static Scanner scanner = new Scanner(System.in);
	UserMasterBean userMasterBean=new UserMasterBean();
	static EmployeeBean employeeBean=new EmployeeBean();
	static IEMSService service =new EMSServiceImpl();
	static IEMSDAO emsDAO=new EMSDAOImpl();
	public static void main(String[] args) throws EmployeeMaintenanceSystemException {
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println(" Employee Maintenance System ");
			System.out.println("_______________________________\n");

			System.out.println("1. Admin Login");
			System.out.println("2. Employee Login");
			System.out.println("3. Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			try {
				int option = scanner.nextInt();

				switch (option) {


				case 1:	System.out.println("Enter User Name:");
				String aName=scanner.next();
				System.out.println("Enter Password");
				String aPassword=scanner.next();
				if(service.isValidAdmin(aName,aPassword)){
					System.out.println("Login Successful :) ");
					System.out.println("1.Add Employee");
					System.out.println("2.Modify Employee");
					System.out.println("3.Display All Employees");
					System.out.println("4.LogOut");
					int option1 = scanner.nextInt();
					scanner.nextLine();
					switch (option1) {


					case 1: System.out.println("Enter EmpId: ");
					String empId=scanner.nextLine();
					scanner.nextLine();

					System.out.println("Enter empFirstName: ");
					String empFirstName=scanner.nextLine();
					scanner.nextLine();

					System.out.println("Enter empLastName: ");
					String empLastName=scanner.nextLine();
					scanner.nextLine();

					System.out.println("Enter empDateOfBirth: ");
					String empDateOfBirth=scanner.nextLine();
					DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
					LocalDate DOB=LocalDate.parse(empDateOfBirth,formatter);
					scanner.nextLine();

					System.out.println("Enter empDateOfJoining");
					String empDateOfJoining=scanner.nextLine();
					DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
					LocalDate DOJ=LocalDate.parse(empDateOfJoining,formatter1);
					scanner.nextLine();

					System.out.println("Enter empDeptId: ");
					Integer empDeptId=scanner.nextInt();
					scanner.nextLine();

					System.out.println("Enter empGrade: ");
					String empGrade=scanner.nextLine();
					scanner.nextLine();

					System.out.println("Enter empDesignation: ");
					String empDesignation=scanner.nextLine();
					scanner.nextLine();

					System.out.println("Enter empBasic: ");
					Integer empBasic=scanner.nextInt();
					scanner.nextLine();

					System.out.println("Enter empGender: ");
					String empGender=scanner.nextLine();
					scanner.nextLine();

					System.out.println("Enter empMaritalStatus: ");
					String empMaritalStatus=scanner.nextLine();
					scanner.nextLine();

					System.out.println("Enter empHomeAddress: ");
					String empHomeAddress=scanner.nextLine();
					scanner.nextLine();

					System.out.println("Enter empContactNum: ");
					String empContactNum=scanner.nextLine();
					scanner.nextLine();
					employeeBean.setEmpId(empId);
					employeeBean.setEmpFirstName(empFirstName);
					employeeBean.setEmpLastName(empLastName);						
					employeeBean.setEmpDateOfBirth(DOB);
					employeeBean.setEmpDateOfJoining(DOJ);
					employeeBean.setEmpDeptId(empDeptId);
					employeeBean.setEmpGrade(empGrade);
					employeeBean.setEmpDesignation(empDesignation);
					employeeBean.setEmpBasic(empBasic);
					employeeBean.setEmpGender(empGender);
					employeeBean.setEmpMaritalStatus(empMaritalStatus);
					employeeBean.setEmpHomeAddress(empHomeAddress);
					employeeBean.setEmpContactNum(empContactNum);

					int n=service.addEmployeeDetails(employeeBean);
					if(n!=0) {
						System.out.println("Succesfully inserted");
					}
					break;  
					case 2:
						System.out.println("Enter your employee Id: ");
						String empid=scanner.nextLine();
						System.out.println("Employee Id:"+empid);
						List<EmployeeBean> empBean2;
						empBean2=service.getAllEmployeeDetails(empid);
						Iterator<EmployeeBean> iterator1=empBean2.iterator();
						while(iterator1.hasNext()){
							System.out.println(iterator1.next());
						}
						System.out.println("\n");
						System.out.println("Modify your Details here...");
						System.out.println("\n");
						System.out.println("Employee id: "+empid);

						System.out.println("Enter new First Name: ");

						String fname=scanner.nextLine();
						System.out.println("New First Name:"+fname);

						System.out.println("Enter New Last Name:");
						String lname=scanner.nextLine();
						System.out.println("New Last Name:"+lname);

						System.out.println("Enter New Dept Id: ");
						Integer deptId=scanner.nextInt();
						System.out.println("New Dept Id: "+deptId);

						System.out.println("Enter new Grade:");
						scanner.nextLine();
						String grade=scanner.nextLine();
						System.out.println("New grade:"+grade);

						System.out.println("Enter new Designation: ");
						String designation=scanner.nextLine();
						System.out.println("New Designation: "+designation);

						System.out.println("Enter New Basic: ");
						Integer basic=scanner.nextInt();
						System.out.println("New Basic: "+basic);

						System.out.println("Enter updated Marital status: ");
						scanner.nextLine();
						String maritalStatus=scanner.nextLine();
						System.out.println("Updated Marital status: "+maritalStatus);

						System.out.println("Enter Updated Home address: ");
						String hAddress=scanner.nextLine();
						System.out.println("Updated Home address: "+hAddress);

						System.out.println("Enter Updated contact no: ");
						String contact=scanner.nextLine();
						System.out.println("Updated Home address: "+contact);

						Integer Update=service.UpdateDetails(empid,fname,lname,deptId,grade,designation,basic,maritalStatus,hAddress,contact);

						if(Update>0){
							System.out.println("Updated Successfully...");
						}
						else{
							System.out.println("Failed to Update...");
						}
						break; 





					case 3:
						List<EmployeeBean> employeeList=getAllEmployeeDetails();
						showEmployee(employeeList);


						break;
					case 4:
						System.out.print("Admin Exited from Employee Maintenance System");
						System.exit(0);
						break;
					default:
						System.out.println("Enter a valid option[1-4]");
					}


				}else System.out.println("Enter valid username and password");


				break;
				case 2:System.out.println("Enter your name: ");
				scanner.nextLine();
				String name=scanner.nextLine();
				//System.out.println(name);
				System.out.println("Enter your password: ");
				String password=scanner.nextLine();	
				if(service.isValidEmployee(name, password)){
					System.out.println("Login Successful :) ");
					System.out.println("1.Search for the Employee");
					System.out.println("2.LogOut");
					int option2 = scanner.nextInt();

					switch (option2) {

					case 1:System.out.println("Enter the option to Search: \n 1.Employee Id \n 2.FirstName \n 3.LastName \n 4.DepartmentID \n 5.grade \n 6.maritalstatus ");
					int options=scanner.nextInt();
					scanner.nextLine();
					{
						switch(options){
						case 1:System.out.println("Enter employeeID");
						String empid=scanner.nextLine();
						List<EmployeeBean> employeeBeans= service.getAllDetailsEmpID(empid);
						Iterator<EmployeeBean> iterator=employeeBeans.iterator();
						while(iterator.hasNext()){
							System.out.println(iterator.next());
						}
						break;
						case 2:System.out.println("Enter FirstName");
						String empFirstName=scanner.nextLine();
						List<EmployeeBean> employeeBeans1= service.getAllDetailsFirstName(empFirstName);
						Iterator<EmployeeBean> iterator1=employeeBeans1.iterator();
						while(iterator1.hasNext()){
							System.out.println(iterator1.next());
						}
						break;
						case 3:System.out.println("Enter LastName");
						String empLastName=scanner.nextLine();
						List<EmployeeBean> employeeBeans2= service.getAllDetailsLastName(empLastName);
						Iterator<EmployeeBean> iterator2=employeeBeans2.iterator();
						while(iterator2.hasNext()){
							System.out.println(iterator2.next());
						}
						break;
						case 4:System.out.println("Enter Department");
						Integer empDeptId=scanner.nextInt();
						List<EmployeeBean> employeeBeans3= service.getAllDetailsDepartmentID(empDeptId);
						Iterator<EmployeeBean> iterator3=employeeBeans3.iterator();
						while(iterator3.hasNext()){
							System.out.println(iterator3.next());
						}
						break;
						case 5:System.out.println("Enter grade");
						String empgrade=scanner.nextLine();
						List<EmployeeBean> employeeBeans4= service.getAllDetailsGrade(empgrade);
						Iterator<EmployeeBean> iterator4=employeeBeans4.iterator();
						while(iterator4.hasNext()){
							System.out.println(iterator4.next());
						}
						break;
						case 6:System.out.println("Enter marital status");
						String empmarital=scanner.nextLine();
						List<EmployeeBean> employeeBeans5= service.getAllDetailsMaritalStatus(empmarital);
						Iterator<EmployeeBean> iterator5=employeeBeans5.iterator();
						while(iterator5.hasNext()){
							System.out.println(iterator5.next());
						}
						break;
						}
					}
					break;
					case 2:
						System.out.print("User Exited from Employee Maintenance System");
						System.exit(0);
						break;
					default:
						System.out.println("Enter a valid option[1-4]");
					}

				}else System.out.println("Enter valid username and password");
				break;



				case 3:

					System.out.print("Exit Employee Maintenance System");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}// end of switch
			}//end of try

			catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while

	}
	private static void showEmployee(List<EmployeeBean> employeeList) {
		if(employeeList!=null){
			Iterator<EmployeeBean> iterator=employeeList.iterator();
			while(iterator.hasNext()){
				System.out.println(iterator.next());
			}
		}else{
			System.out.println("No data found");
		}


	}
	private static List<EmployeeBean> getAllEmployeeDetails() throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeList=emsDAO.getAllEmployeeDetails();
		return employeeList;


	}

}


