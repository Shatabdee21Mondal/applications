package org.capgemini.ems.bean;

import java.time.LocalDate;



public class EmployeeBean {
	
	private String empId;
	private String empFirstName;
	private String empLastName;
	private LocalDate empDateOfBirth;
	private LocalDate empDateOfJoining;
	private Integer empDeptId;
	private String empGrade;
	private String empDesignation;
	private Integer empBasic;
	private String empGender;
	private String empMaritalStatus;
	private String empHomeAddress;
	private String empContactNum;
	
	public EmployeeBean() {
		super();
	}

	public EmployeeBean(String empId, String empFirstName, String empLastName,
			LocalDate empDateOfBirth, LocalDate empDateOfJoining,
			Integer empDeptId, String empGrade, String empDesignation,
			Integer empBasic, String empGender, String empMaritalStatus,
			String empHomeAddress, String empContactNum) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasic = empBasic;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNum = empContactNum;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public LocalDate getEmpDateOfBirth() {
		return empDateOfBirth;
	}

	public void setEmpDateOfBirth(LocalDate empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}

	public LocalDate getEmpDateOfJoining() {
		return empDateOfJoining;
	}

	public void setEmpDateOfJoining(LocalDate empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}

	public Integer getEmpDeptId() {
		return empDeptId;
	}

	public void setEmpDeptId(Integer empDeptId) {
		this.empDeptId = empDeptId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public Integer getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(Integer empBasic) {
		this.empBasic = empBasic;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}

	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}

	public String getEmpHomeAddress() {
		return empHomeAddress;
	}

	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}

	public String getEmpContactNum() {
		return empContactNum;
	}

	public void setEmpContactNum(String empContactNum) {
		this.empContactNum = empContactNum;
	}

	@Override
	public String toString() {
		return "EmployeeBean [empId=" + empId + ", empFirstName="
				+ empFirstName + ", empLastName=" + empLastName
				+ ", empDateOfBirth=" + empDateOfBirth + ", empDateOfJoining="
				+ empDateOfJoining + ", empDeptId=" + empDeptId + ", empGrade="
				+ empGrade + ", empDesignation=" + empDesignation
				+ ", empBasic=" + empBasic + ", empGender=" + empGender
				+ ", empMaritalStatus=" + empMaritalStatus
				+ ", empHomeAddress=" + empHomeAddress + ", empContactNum="
				+ empContactNum + "]";
	}
	
	
}
