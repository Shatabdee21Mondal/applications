package org.capgemini.ems.bean;

public class GradeMasterBean {

	private String gradeCode;
	private String description;
	private Double minSalary;
	private Double maxSalary;

	public GradeMasterBean() {
		super();
	}

	public GradeMasterBean(String gradeCode, String description, Double minSalary, Double maxSalary) {
		super();
		this.gradeCode = gradeCode;
		this.description = description;
		this.minSalary = minSalary;
		this.maxSalary = maxSalary;
	}

	public String getGradeCode() {
		return gradeCode;
	}

	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(Double minSalary) {
		this.minSalary = minSalary;
	}

	public Double getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(Double maxSalary) {
		this.maxSalary = maxSalary;
	}

	@Override
	public String toString() {
		return 	"Grade Code=" + gradeCode + "\t" +
				"Description=" + description + "\t" + 
				"Minimum Salary=" + minSalary + "\t" +
				"Maximum Salary=" + maxSalary;
	}




}



