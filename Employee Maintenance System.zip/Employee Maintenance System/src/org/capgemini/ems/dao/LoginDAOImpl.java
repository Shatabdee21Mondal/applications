package org.capgemini.ems.dao;

import org.capgemini.ems.bean.UserMasterBean;

public class LoginDAOImpl implements ILoginDAO{

	@Override
	public boolean isValidLogin(UserMasterBean userMasterBean) {
		
		return false;
	}

}
