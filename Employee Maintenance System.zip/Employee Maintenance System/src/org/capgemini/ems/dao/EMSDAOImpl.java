package org.capgemini.ems.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;
import org.capgemini.ems.util.DBConnection;



public class EMSDAOImpl implements IEMSDAO{
	int employeeCount=0;
	static EmployeeBean employeeBean=new EmployeeBean();
	@Override
	public boolean isValidEmployee(String name, String password) throws EmployeeMaintenanceSystemException{

		String sql="select * from user_master where username=? AND  userpassword=? And usertype=?";
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedstatement=connection.prepareStatement(sql);
			preparedstatement.setString(1, name);
			preparedstatement.setString(2, password);
			preparedstatement.setString(3, "Employee");

			ResultSet resultSet=preparedstatement.executeQuery();
			if(resultSet.next()){
				return true;

			}

		}catch(SQLException e){

		} catch (EmployeeMaintenanceSystemException e) {

			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean isValidAdmin(String aName, String aPassword) throws EmployeeMaintenanceSystemException{


		String sql="select * from user_master where username=? AND  userpassword=? And usertype=?";
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedstatement=connection.prepareStatement(sql);
			preparedstatement.setString(1, aName);
			preparedstatement.setString(2, aPassword);
			preparedstatement.setString(3, "admin");

			ResultSet resultSet=preparedstatement.executeQuery();
			if(resultSet.next()){
				return true;

			}

		}catch(SQLException e){

		} catch (EmployeeMaintenanceSystemException e) {

			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetails() throws EmployeeMaintenanceSystemException{

		try(
				Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			ResultSet resultSet=statement.executeQuery("select * from Employeems");
			List<EmployeeBean> employeeList=new ArrayList<>();
			while(resultSet.next()){
				employeeCount++;
				EmployeeBean employee=new EmployeeBean();					
				populateEmployee(employee,resultSet);
				employeeList.add(employee);
			}
			if(employeeCount!=0){
				return employeeList;
			}else{
				return null;
			}
		}catch(SQLException e){
			//myDAOLogger.error(e.getMessage());
			throw new EmployeeMaintenanceSystemException("Technical error!! Refer to Logs");
			//e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}

		return null;

	}

	private void populateEmployee(EmployeeBean employee, ResultSet resultSet) throws SQLException {
		employee.setEmpId(resultSet.getString("Emp_ID"));
		employee.setEmpFirstName(resultSet.getString("Emp_First_Name"));
		employee.setEmpLastName(resultSet.getString("Emp_Last_Name"));

		java.sql.Date sqlDate=resultSet.getDate(4);
		java.util.Date utilDate = new java.util.Date(sqlDate.getTime());
		Instant instant = Instant.ofEpochMilli(utilDate.getTime()); 
		LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()); 
		LocalDate localDate = localDateTime.toLocalDate();
		employee.setEmpDateOfBirth(localDate);

		java.sql.Date sqlDate1=resultSet.getDate(5);
		java.util.Date utilDate1 = new java.util.Date(sqlDate1.getTime());
		Instant instant1 = Instant.ofEpochMilli(utilDate1.getTime()); 
		LocalDateTime localDateTime1 = LocalDateTime.ofInstant(instant1, ZoneId.systemDefault()); 
		LocalDate localDate1 = localDateTime1.toLocalDate();
		employee.setEmpDateOfJoining((localDate1));


		employee.setEmpDeptId(resultSet.getInt("Emp_Dept_ID"));
		employee.setEmpGrade(resultSet.getString("Emp_Grade"));
		employee.setEmpDesignation(resultSet.getString("Emp_Designation"));
		employee.setEmpBasic(resultSet.getInt("Emp_Basic"));
		employee.setEmpGender(resultSet.getString("Emp_Gender"));
		employee.setEmpMaritalStatus(resultSet.getString("Emp_Marital_Status"));
		employee.setEmpHomeAddress(resultSet.getString("Emp_Home_Address"));
		employee.setEmpContactNum(resultSet.getString("Emp_Contact_Num"));


	}

	@Override
	public Integer addEmployeeDetails(EmployeeBean employeeBean)
			throws EmployeeMaintenanceSystemException {


		String sql3="insert into Employeems values(?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(sql3);
				) {
			preparedStatement.setString(1, employeeBean.getEmpId());
			preparedStatement.setString(2, employeeBean.getEmpFirstName());
			preparedStatement.setString(3, employeeBean.getEmpLastName());
			preparedStatement.setDate(4, Date.valueOf(employeeBean.getEmpDateOfBirth()));
			preparedStatement.setDate(5,Date.valueOf(employeeBean.getEmpDateOfJoining()));
			preparedStatement.setInt(6, employeeBean.getEmpDeptId());
			preparedStatement.setString(7, employeeBean.getEmpGrade());
			preparedStatement.setString(8, employeeBean.getEmpDesignation());
			preparedStatement.setInt(9, employeeBean.getEmpBasic());
			preparedStatement.setString(10, employeeBean.getEmpGender());
			preparedStatement.setString(11, employeeBean.getEmpMaritalStatus());
			preparedStatement.setString(12, employeeBean.getEmpHomeAddress());
			preparedStatement.setString(13, employeeBean.getEmpContactNum());
			int n=preparedStatement.executeUpdate();
			if(n!=0) {
				return n;
			}

		}catch(SQLException e) {
			//daoLogger.error(e);
			throw new EmployeeMaintenanceSystemException("Tech Error. Refer Logs");
		}
		return null;



	}


	@Override
	public Integer UpdateDetails(String empid,String fname, String lname, Integer deptId,
			String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact) {

		String sql="update employeems set emp_first_name=?,emp_last_name=?,emp_dept_id=?,emp_grade=?,emp_designation=?,emp_basic=?,emp_marital_status=?,emp_home_address=?,emp_contact_num=? where emp_id=?";

		try(Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(sql);

				){
			preparedStatement.setString(1, fname);
			preparedStatement.setString(2, lname);
			preparedStatement.setInt(3, deptId);
			preparedStatement.setString(4, grade);
			preparedStatement.setString(5, designation);
			preparedStatement.setInt(6, basic);
			preparedStatement.setString(7, maritalStatus);
			preparedStatement.setString(8, hAddress);
			preparedStatement.setString(9, contact);
			preparedStatement.setString(10, empid);

			int n=preparedStatement.executeUpdate();
			if(n>0){
				return n;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EmployeeMaintenanceSystemException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null; 

	} 
	@Override
	public List<EmployeeBean> getAllEmployeeDetails(String empid) {


		List<EmployeeBean> employeeBeans=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employeems where emp_ID=?");
			preparedStatement.setString(1,empid);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				System.out.println(empl.getEmpLastName());
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				System.out.println(empl.getEmpDateOfBirth());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans.add(empl);

			}
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (EmployeeMaintenanceSystemException e) {

			e.printStackTrace();
		}
		return employeeBeans;

	}

	@Override
	public List<EmployeeBean> getAllDetailsEmpID(String empid) throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employeems where emp_ID=?");
			preparedStatement.setString(1,empid);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans.add(empl);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return employeeBeans;
		
	}

	@Override
	public List<EmployeeBean> getAllDetailsFirstName(String empFirstName) throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans1=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employeems where EMP_FIRST_NAME=?");
			preparedStatement.setString(1,empFirstName);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans1.add(empl);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return employeeBeans1;
	}

	@Override
	public List<EmployeeBean> getAllDetailsLastName(String empLastName) throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans2=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employeems where EMP_LAST_NAME=?");
			preparedStatement.setString(1,empLastName);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans2.add(empl);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return employeeBeans2;
	}

	@Override
	public List<EmployeeBean> getAllDetailsDepartmentID(Integer empDeptId) throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans3=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employeems where EMP_DEPT_ID=?");
			preparedStatement.setInt(1,empDeptId);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans3.add(empl);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return employeeBeans3;
	}

	@Override
	public List<EmployeeBean> getAllDetailsGrade(String empgrade) throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans4=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employeems where EMP_grade=?");
			preparedStatement.setString(1,empgrade);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans4.add(empl);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return employeeBeans4;
	}

	@Override
	public List<EmployeeBean> getAllDetailsMaritalStatus(String empmarital) throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeBeans5=new ArrayList<EmployeeBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement
					("select * from Employeems where EMP_MARITAL_STATUS=?");
			preparedStatement.setString(1,empmarital);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				EmployeeBean empl=new EmployeeBean();
				empl.setEmpId(resultSet.getString("emp_Id"));
				empl.setEmpFirstName(resultSet.getString("emp_First_Name"));
				empl.setEmpLastName(resultSet.getString("emp_Last_Name"));
				empl.setEmpDateOfBirth(resultSet.getDate("emp_Date_Of_Birth").toLocalDate());
				empl.setEmpDateOfJoining(resultSet.getDate("emp_Date_Of_Joining").toLocalDate());
				empl.setEmpDeptId(resultSet.getInt("emp_Dept_Id"));
				empl.setEmpGrade(resultSet.getString("emp_Grade"));
				empl.setEmpDesignation(resultSet.getString("emp_Designation"));
				empl.setEmpBasic(resultSet.getInt("emp_Basic"));
				empl.setEmpGender(resultSet.getString("emp_Gender"));
				empl.setEmpHomeAddress(resultSet.getString("emp_Home_Address"));
				empl.setEmpMaritalStatus(resultSet.getString("emp_Marital_Status"));
				empl.setEmpContactNum(resultSet.getString("emp_Contact_Num"));
				employeeBeans5.add(empl);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return employeeBeans5;
	} 






}