package org.capgemini.ems.service;


import java.util.List;

import org.capgemini.ems.bean.DepartmentBean;
import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;


public interface IAdminService {
	
	public boolean isValidAdmin(String aName, String aPassword) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllEmployeeDetails() throws EmployeeMaintenanceSystemException;

	public Integer addEmployeeDetails(EmployeeBean employeeBean) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllEmployeeDetails(String empid) throws EmployeeMaintenanceSystemException;
	
	public abstract Integer UpdateDetails(String empid, String fname, String lname,
			Integer deptId, String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact) throws EmployeeMaintenanceSystemException;
	
	public List<DepartmentBean> displayDepartmentDetails() throws EmployeeMaintenanceSystemException;
	
	public boolean isValidEmpId(String empid) throws EmployeeMaintenanceSystemException;


}
