package org.capgemini.ems.service;


import java.util.List;

import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.dao.EMSDAOImpl;
import org.capgemini.ems.dao.IEMSDAO;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;



public class EMSServiceImpl implements IEMSService{
	private IEMSDAO emsDAO=new EMSDAOImpl();
	UserMasterBean userMasterBean=new UserMasterBean();
	@Override
	public boolean isValidEmployee(String name, String password) throws EmployeeMaintenanceSystemException{

		return emsDAO.isValidEmployee(name, password);
	}
	@Override
	public boolean isValidAdmin(String aName, String aPassword) throws EmployeeMaintenanceSystemException{

		return emsDAO.isValidAdmin(aName,aPassword);
	}
	@Override
	public List<EmployeeBean> getAllEmployeeDetails()
			throws EmployeeMaintenanceSystemException {

		List<EmployeeBean> employeeList=emsDAO.getAllEmployeeDetails();
		return employeeList;

	}
	@Override
	public Integer addEmployeeDetails(EmployeeBean employeeBean)
			throws EmployeeMaintenanceSystemException {

		return emsDAO.addEmployeeDetails(employeeBean);
	}
	@Override
	public Integer UpdateDetails(String empid, String fname, String lname,
			Integer deptId, String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact)
					throws EmployeeMaintenanceSystemException {

		return emsDAO.UpdateDetails(empid, fname, lname, deptId, grade, designation, basic, maritalStatus, hAddress, contact);
	}
	
	@Override
	public List<EmployeeBean> getAllEmployeeDetails(String empid) throws EmployeeMaintenanceSystemException {

		return emsDAO.getAllEmployeeDetails();
	}
	@Override
	public List<EmployeeBean> getAllDetailsEmpID(String empid) throws EmployeeMaintenanceSystemException{
		
		return emsDAO.getAllDetailsEmpID(empid);
	}
	@Override
	public List<EmployeeBean> getAllDetailsFirstName(String empFirstName) throws EmployeeMaintenanceSystemException{
		
		return emsDAO.getAllDetailsFirstName(empFirstName);
	}
	@Override
	public List<EmployeeBean> getAllDetailsLastName(String empLastName) throws EmployeeMaintenanceSystemException{
		
		return emsDAO.getAllDetailsLastName(empLastName);
	}
	@Override
	public List<EmployeeBean> getAllDetailsDepartmentID(Integer empDeptId) throws EmployeeMaintenanceSystemException{
		
		return emsDAO.getAllDetailsDepartmentID(empDeptId);
	}
	@Override
	public List<EmployeeBean> getAllDetailsGrade(String empgrade) throws EmployeeMaintenanceSystemException{
		
		return emsDAO.getAllDetailsGrade(empgrade);
	}
	@Override
	public List<EmployeeBean> getAllDetailsMaritalStatus(String empmarital) throws EmployeeMaintenanceSystemException {
		
		return emsDAO.getAllDetailsMaritalStatus(empmarital);
	}


}
