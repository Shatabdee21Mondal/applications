package org.capgemini.ems.service;


import java.util.List;

import org.capgemini.ems.bean.DepartmentBean;
import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.dao.AdminDAOImpl;
import org.capgemini.ems.dao.IAdminDAO;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;



public class AdminServiceImpl implements IAdminService{
	private IAdminDAO adminDAO=new AdminDAOImpl();
	UserMasterBean userMasterBean=new UserMasterBean();
	
	@Override
	public boolean isValidAdmin(String aName, String aPassword) throws EmployeeMaintenanceSystemException{

		return adminDAO.isValidAdmin(aName,aPassword);
	}
	@Override
	public List<EmployeeBean> getAllEmployeeDetails()
			throws EmployeeMaintenanceSystemException {

		List<EmployeeBean> employeeList=adminDAO.getAllEmployeeDetails();
		return employeeList;

	}
	@Override
	public Integer addEmployeeDetails(EmployeeBean employeeBean)
			throws EmployeeMaintenanceSystemException {

		return adminDAO.addEmployeeDetails(employeeBean);
	}
	@Override
	public Integer UpdateDetails(String empid, String fname, String lname,
			Integer deptId, String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact)
					throws EmployeeMaintenanceSystemException {

		return adminDAO.UpdateDetails(empid, fname, lname, deptId, grade, designation, basic, maritalStatus, hAddress, contact);
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetails(String empid) throws EmployeeMaintenanceSystemException {

		return adminDAO.getAllEmployeeDetails(empid);
	}
	
	@Override
	public List<DepartmentBean> displayDepartmentDetails()
			throws EmployeeMaintenanceSystemException {
		List<DepartmentBean> bean=adminDAO.displayDepartmentDetails();

		return bean;

	}
	@Override
	public boolean isValidEmpId(String empid)
			throws EmployeeMaintenanceSystemException {
		
		return adminDAO.isValidEmpId(empid);
	}


}
