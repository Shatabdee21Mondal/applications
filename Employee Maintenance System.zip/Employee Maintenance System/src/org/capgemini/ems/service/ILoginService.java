package org.capgemini.ems.service;

import org.capgemini.ems.bean.UserMasterBean;

public interface ILoginService {
	public boolean isValidLogin(UserMasterBean userMasterBean);
}
