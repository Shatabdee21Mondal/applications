package org.capgemini.ems.service;


import java.util.List;

import org.capgemini.ems.bean.DepartmentBean;
import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;


public interface IEMSService {
	public boolean isValidEmployee(String name, String password) throws EmployeeMaintenanceSystemException;

	public boolean isValidAdmin(String aName, String aPassword) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllEmployeeDetails() throws EmployeeMaintenanceSystemException;

	public Integer addEmployeeDetails(EmployeeBean employeeBean) throws EmployeeMaintenanceSystemException;

	public abstract Integer UpdateDetails(String empid, String fname, String lname,
			Integer deptId, String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllEmployeeDetails(String empid) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsEmpID(String empid) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsFirstName(String empFirstName) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsLastName(String empLastName) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsDepartmentID(Integer empDeptId) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsGrade(String empgrade) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllDetailsMaritalStatus(String empmarital) throws EmployeeMaintenanceSystemException;

	public List<DepartmentBean> displayDepartmentDetails() throws EmployeeMaintenanceSystemException;


}
