package org.capgemini.ems.service;

import java.util.List;

import org.capgemini.ems.bean.EmployeeBean;
import org.capgemini.ems.bean.UserMasterBean;
import org.capgemini.ems.dao.EmployeeDAOImpl;
import org.capgemini.ems.dao.IEmployeeDAO;
import org.capgemini.ems.exception.EmployeeMaintenanceSystemException;

public class EmployeeServiceImpl implements IEmployeeService {
	UserMasterBean userMasterBean=new UserMasterBean();
	private IEmployeeDAO empDAO=new EmployeeDAOImpl();
	@Override
	public boolean isValidEmployee(String name, String password) throws EmployeeMaintenanceSystemException{

		return empDAO.isValidEmployee(name, password);
	}
	
	@Override
	public List<EmployeeBean> getAllDetailsEmpID(String empid) throws EmployeeMaintenanceSystemException{

		return empDAO.getAllDetailsEmpID(empid);
	}
	@Override
	public List<EmployeeBean> getAllDetailsFirstName(String empFirstName) throws EmployeeMaintenanceSystemException{

		return empDAO.getAllDetailsFirstName(empFirstName);
	}
	@Override
	public List<EmployeeBean> getAllDetailsLastName(String empLastName) throws EmployeeMaintenanceSystemException{

		return empDAO.getAllDetailsLastName(empLastName);
	}
	@Override
	public List<EmployeeBean> getAllDetailsDepartmentID(Integer empDeptId) throws EmployeeMaintenanceSystemException{

		return empDAO.getAllDetailsDepartmentID(empDeptId);
	}
	@Override
	public List<EmployeeBean> getAllDetailsGrade(String empgrade) throws EmployeeMaintenanceSystemException{

		return empDAO.getAllDetailsGrade(empgrade);
	}
	@Override
	public List<EmployeeBean> getAllDetailsMaritalStatus(String empmarital) throws EmployeeMaintenanceSystemException {

		return empDAO.getAllDetailsMaritalStatus(empmarital);
	}
	

}
