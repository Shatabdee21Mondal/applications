package org.capgemini.ems.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidationTest {

	@Test
	public void testIsValidEmpId() {
		assertTrue(new Validation().isValidEmpId("161642"));
	}
	@Test
	public void testIsNotValidEmpId() {
		assertFalse(new Validation().isValidEmpId("xyz"));
	}
	
	
	
	@Test
	public void testIsValidFirstName() {
		assertTrue(new Validation().isValidFirstName("Shatabdee"));
	}
	
	@Test
	public void testIsNotValidFirstName() {
		assertFalse(new Validation().isValidFirstName("123654"));
	}
	
	@Test
	public void testIsValidLastName() {
		assertTrue(new Validation().isValidLastName("Mondal"));
	}
	
	@Test
	public void testIsNotValidLastName() {
		assertFalse(new Validation().isValidLastName("1251Adbjh"));
	}
	
	@Test
	public void testIsValidDOB(){
		assertTrue(new Validation().isValidDOB("21/09/1997"));
	}
	
	@Test
	public void testIsNotValidDOB(){
		assertFalse(new Validation().isValidDOB("sep-21-1997"));
	}
	
	
	@Test
	public void testIsValidDOJ() {
		assertTrue(new Validation().isValidDOJ("19/09/2018"));
	}
	
	@Test
	public void testIsNotValidDOJ() {
		assertFalse(new Validation().isValidDOJ("sep-21-1997"));
	}
	
	@Test
	public void testIsValidGrade() {
		assertTrue(new Validation().isValidGrade("M1"));
	}
	@Test
	public void testIsNotValidGrade() {
		assertFalse(new Validation().isValidGrade("m1"));
	}
	
	
	
	@Test
	public void testIsValidGender() {
		assertTrue(new Validation().isValidGender("Female"));
	}
	
	@Test
	public void testIsNotValidGender() {
		assertFalse(new Validation().isValidGender("S"));
	}
	
	
	
	@Test
	public void testIsValidMartialStatus() {
		assertTrue(new Validation().isValidMartialStatus("Single"));
	}
	
	@Test
	public void testIsNotValidMartialStatus() {
		assertFalse(new Validation().isValidMartialStatus("Abcd"));
	}
	
	@Test
	public void testIsValidHomeAddress() {
		assertTrue(new Validation().isValidHomeAddress(""));
	}
	
	@Test
	public void testIsNotValidHomeAddress() {
		assertFalse(new Validation().isValidHomeAddress("Hyd-86"));
	}
	
	@Test
	public void testIsValidContactNumber() {
		assertTrue(new Validation().isValidContactNumber("9705409887Sh"));
	}
	
	@Test
	public void testIsNotValidContactNumber() {
		assertFalse(new Validation().isValidContactNumber("9705409887@Sh"));
	}

}
